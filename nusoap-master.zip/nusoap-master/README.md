nusoap
======

Nusoap PHP library 

Copy of original library for supporting packagist composer.

More info at project webite http://nusoap.sourceforge.net/


